package page;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class CheckerPage {
    private WebDriver driver;

    public CheckerPage(WebDriver driver) {
        this.driver = driver;
    }

    private By cooKies = By.id("nhsuk-cookie-banner__link_accept_analytics");
    private By startnow = By.id("next-button");
    private By walesradio = By.id("radio-wales");
    private By nextbutton = By.id("next-button");
    private By yesradio = By.id("radio-yes");
    private By gpradio = By.id("radio-wales");
    private By daybox = By.cssSelector("input[id=\"dob-day\"]");
    private By monthbox = By.id("dob-month");
    private By yearbox = By.id("dob-year");
    private By noRadio = By.xpath("//input[@id='radio-no']");
    private By savingsButton = By.xpath("//label[@id='label-no']");
    private By resultText = By.xpath("//div[@class=\"column-two-thirds\"]/ul");

    public void setCooKies() {
        driver.findElement(cooKies).click();
    }

    public void setStartnow() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
        driver.findElement(startnow).click();
    }

    public void setWalesradio() {
        driver.findElement(walesradio).click();
    }

    public void setNextbutton() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,300)");
        driver.findElement(nextbutton).click();
    }

    public void setYesradio() {
        driver.findElement(yesradio).click();
    }

    public void setGpradio() {
        driver.findElement(gpradio).click();
    }

    public void setDOB(String day, String month, String year) {
        driver.findElement(daybox).sendKeys(day);
        driver.findElement(monthbox).sendKeys(month);
        driver.findElement(yearbox).sendKeys(year);
    }


    public void setNoradio() {
        driver.findElement(noRadio).click();
    }
    public void setSavingsButton(){
        driver.findElement(savingsButton).click();
    }

    public String verifyCheckerToolResult() {
        return driver.findElement(resultText).getText();
    }

}



