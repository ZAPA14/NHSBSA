package steps;

import factory.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import page.CheckerPage;

public class CheckerToolSteps {

    CheckerPage checkerPage = new CheckerPage(DriverFactory.getDriver());

    @Given("User is on NHS Checker tool Website")
    public void user_is_on_nhs_checker_tool_website() throws Exception {
        DriverFactory.getDriver().get("https://services.nhsbsa.nhs.uk/check-for-help-paying-nhs-costs/start");
        Thread.sleep(5000);
        checkerPage.setCooKies();

    }

    @When("User select start now button")
    public void user_click_on_start_now_button() throws Exception {
        Thread.sleep(5000);
        checkerPage.setStartnow();

    }

    @When("User select Wales and click on next button")
    public void user_select_wales_and_click_on_next_button() throws Exception {
        Thread.sleep(5000);
        checkerPage.setWalesradio();
        Thread.sleep(5000);
        checkerPage.setNextbutton();

    }

    @When("User select yes for GP practice in Wales")
    public void user_select_yes_for_GP_practice_in_Wales() {
        checkerPage.setYesradio();
        checkerPage.setNextbutton();

    }

    @When("User select yes for Dental practice in Wales")
    public void user_select_yes_for_Dental_practice_in_Wales() {
        checkerPage.setGpradio();
        checkerPage.setNextbutton();
    }

    @When("User enter DOB as day {string} month {string} year {string}")
    public void userEnterDOBAsDayMonthYear(String day, String month, String year) {
        checkerPage.setDOB(day, month, year);
        checkerPage.setNextbutton();
    }


    @When("User select no for living partner and tax benefits")
    public void user_select_no_for_living_partner_and_tax_benefits() {
        checkerPage.setNoradio();
        checkerPage.setNextbutton();
    }

    @When("User select no radio button for pregnant and physical disability")
    public void user_select_no_radio_button_for_pregnant_and_physical_disability() {
        checkerPage.setNoradio();
        checkerPage.setNextbutton();
        checkerPage.setNoradio();
        checkerPage.setNextbutton();

    }

    @When("User select no radio button Diabetic and glaucoma")
    public void user_select_no_radio_button_diabetic_and_glaucoma() {
        checkerPage.setNoradio();
        checkerPage.setNextbutton();
        checkerPage.setNoradio();
        checkerPage.setNextbutton();

    }

    @When("User select no radio button for care home")
    public void user_select_no_radio_button_for_care_home() throws Exception{
        checkerPage.setNoradio();
        checkerPage.setNextbutton();
    }

    @When("User select no radio button for savings")
    public void user_select_no_radio_button_for_savings() throws Exception  {
        checkerPage.setSavingsButton();
        checkerPage.setNextbutton();
        Thread.sleep(5000);

    }
    @Then("User must get the result for NHS can give help or not and verify it")
    public void user_must_get_the_result_for_nhs_can_give_help_or_not_and_verify_it() throws Exception {
        Thread.sleep(15000);
        String actual = checkerPage.verifyCheckerToolResult();
        System.out.println(">>>>>>>>>>>>>" +actual);
       // String expected = "";
       // Assert.assertEquals("The checkTool message is " + expected,actual);
    }
}





