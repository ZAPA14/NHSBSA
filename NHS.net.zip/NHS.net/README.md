The step that enables this logging is `I log the worldpay transaction details`

# PPBO UI Acceptance Tests

This project contains acceptance level UI tests for the priority Pass BackOffice

The tests cover major Backoffice function with an emphasis on covering user journey

## Coverage

The following is a snapshot of the current coverage as implemented.It is planned to 

-Logging in as users on different service centres
-Creating Source Codes(PP and LK)
-Adding Price Codes to Source Codes(PP and LK)
-Digital Failed Payments (Email notifications)

## Setting up the project

### Pre-requisites

-Java 8 installed and environment variable `JAVA_HOME` defined
-Maven 3.5.4(minimum) installed and environment variable `M2_HOME` defined

### Building the project

Build the project using `mvn clean compile`

Build will fail if checkstyle rules are not met. Checkstyle rules are defined in `checkstyle .xml`

### Optional reporting fields

We can add some extra information to our Serenity reports with `Duser`and `Dversion` .These will appear as `User` and `Application Version`in report.

### Running test locally

To run all test with the default configuration,use the `mvn clean verify`command.However, in most cases we need to supply additional options to the command so that our test will run.